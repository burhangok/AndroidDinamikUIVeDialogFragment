package burhangok.cafeyonetimsistemi;

import android.annotation.SuppressLint;
import android.support.annotation.Dimension;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sothree.slidinguppanel.SlidingUpPanelLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout mainLayout;
    List<Button> buttonList = new ArrayList<>();





    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


     mainLayout= findViewById(R.id.mainLayout);

     TextView titleTV = new TextView(this);
        titleTV.setText("İSMEK FATİH BİLİŞİM OKULU");
        titleTV.setTextColor(R.color.colorAccent);
        titleTV.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT));

 mainLayout.addView(titleTV);

       for (int i =1; i<=3; i++) {

            Button button = new Button(this);
            button.setId(i);
            button.setText("MASA "+i);
            button.setHeight(40);
            button.setWidth(60);
            button.setOnClickListener(this);
            buttonList.add(button);

            mainLayout.addView(button);
        }



    }

    @Override
    public void onClick(View v) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        RecipesFragment recipesFragment = new RecipesFragment();
        recipesFragment.show(fragmentManager,"MENU");



    }
}
